//: Playground - noun: a place where people can play

import UIKit


enum Velocidades:Int{
    case Apagado=0,VelocidadBaja=20,VelocidadMedia=50,VelocidadAlta=120
    
    init(velocidadInicial:Velocidades){
        self=velocidadInicial
    }
}

class Auto{
    var velocidad :Velocidades
    init(){
        velocidad=Velocidades(velocidadInicial: Velocidades.Apagado)
    }
    func cambioDeVelocidad()->(actual :Int,velocidadEnCadena : String){
        var actual : Int = velocidad.rawValue
        //print("valor actual \(velocidad.rawValue)")
        var velocidadEnCadena = String(velocidad)
        
        switch actual {
        case 0:
            velocidad=Velocidades.VelocidadBaja
        case 20:
            velocidad=Velocidades.VelocidadMedia
        case 50:
             velocidad=Velocidades.VelocidadAlta
        case 120:
            velocidad=Velocidades.VelocidadMedia
        default:
            print ("Error")
        }
      
        return (actual,velocidadEnCadena)
    }
}

var myAuto = Auto()
for i in 0 ..< 20 {
var (vel,estado)=myAuto.cambioDeVelocidad()
print(" \(vel),\(estado)")

}
